package com.abc_project.aadil.repositories;

import com.abc_project.aadil.models.Call_Information;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface Call_InformationRepository extends MongoRepository<Call_Information, String> {
	Call_Information findBy_id(ObjectId _id);
}