package com.abc_project.aadil.models;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

public class Call_Information {
  @Id
  public ObjectId _id;
  
  public int cust_no;
  public String source;
  public String destination;
  public String source_location;
  public String destination_location;
  public int call_duration;
  public boolean roaming;
  public int call_charge;
  
  // Constructors
  public Call_Information() {}
  
  public Call_Information(ObjectId _id, int cust_no, String source, String destination, String source_location, String destination_location, int call_duration, boolean roaming, int call_charge ) {
    this._id = _id;
    this.cust_no=cust_no;
    this.source = source;
    this.destination = destination;
    this.source_location = source_location;
    this.destination_location = destination_location;
    this.call_duration = call_duration;
    this.roaming=roaming;
    this.call_charge=call_charge;
  }
//ObjectId needs to be converted to string
 public String get_id() { return _id.toHexString(); }
 public void set_id(ObjectId _id) { this._id = _id; }
 
 public int getCustNo() { return cust_no; }
 public void setCustNo(int cust_no) { this.cust_no = cust_no; }
 
 public String getSource() { return source; }
 public void setSource(String source) { this.source = source; }
 
 public String getDestination() { return destination; }
 public void setDestination(String destination) { this.destination = destination; }
 
 public String getSourceLocation() { return source_location; }
 public void setSourceLocation(String source_location) { this.source_location = source_location; }
 
 public String getDestinationLocation() { return destination_location; }
 public void setDestinationLocation(String destination_location) { this.destination_location = destination_location; }
 
 public int getCallDuration() { return call_duration; }
 public void setCallDuration(int call_duration) { this.call_duration = call_duration; }
 
 public boolean getRoamingFlag() { return roaming; }
 public void setRoamingFlag(boolean roaming) { this.roaming = roaming; }
 
 public int getCallCharge() { return call_charge; }
 public void setCallCharge(int call_charge) { this.call_charge = call_charge; }
 
 //public String getBreed() { return breed; }
 //public void setBreed(String breed) { this.breed = breed; }
}