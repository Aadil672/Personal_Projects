package com.abc_project.aadil.controller;

//import com.abc_project.aadil.abcAPI.models.Call_Information;
import com.abc_project.aadil.models.Call_Information;
import com.abc_project.aadil.repositories.Call_InformationRepository;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/Call_Information")
public class Call_InformationRestController {
  @Autowired
  private Call_InformationRepository repository;


@RequestMapping(value = "/", method = RequestMethod.GET)
  public List<Call_Information> getAllCall_Information() {
    return repository.findAll();
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET)
  public Call_Information getCall_InformationById(@PathVariable("id") ObjectId id) {
    return repository.findBy_id(id);
  }
  
  @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
  public void modifyCall_InformationById(@PathVariable("id") ObjectId id, @Valid @RequestBody Call_Information Call_Information) {
    Call_Information.set_id(id);
    repository.save(Call_Information);
  }
  
  @RequestMapping(value = "/", method = RequestMethod.POST)
  public Call_Information createCall_Information(@Valid @RequestBody Call_Information Call_Information) {
    Call_Information.set_id(ObjectId.get());
    repository.save(Call_Information);
    return Call_Information;
  }
  
  @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
  public void deleteCall_Information(@PathVariable ObjectId id) {
    repository.delete(repository.findBy_id(id));
  }
}