package com.abc_project.aadil.abcAPI;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AbcApiApplicationTests {

	@Test
	public void contextLoads() {
	}

}
